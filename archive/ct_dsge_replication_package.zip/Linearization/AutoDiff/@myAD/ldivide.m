function x = ldivide(x,y)
  x=rdivide(y,x);
end
