function [vecX] = vec(X)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
vecX = X(:);
end